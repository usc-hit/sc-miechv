-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 21, 2013 at 12:51 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `miechv`
--

-- --------------------------------------------------------

--
-- Table structure for table `asq_screening`
--

CREATE TABLE IF NOT EXISTS `asq_screening` (
  `ASQ_SCREENING_ID` bigint(20) NOT NULL,
  `CHILD_ID` bigint(20) NOT NULL,
  `EPSDT_VISITS` varchar(20) DEFAULT NULL,
  `COMMUNICATION_SCREEN` tinyint(1) NOT NULL,
  `COMMUNICATION_PROBLEM` tinyint(1) NOT NULL,
  `COMMUNICATION_REFERRAL` tinyint(1) NOT NULL,
  `PERSONAL_SCREEN` tinyint(1) NOT NULL,
  `PERSONAL_PROBLEM` tinyint(1) NOT NULL,
  `PERSONAL_REFERRAL` tinyint(1) NOT NULL,
  `SOLVING_SCREEN` tinyint(1) NOT NULL,
  `SOLVING_PROBLEM` tinyint(1) NOT NULL,
  `SOLVING_REFERRAL` tinyint(1) NOT NULL,
  `EMOTIONAL_SCREEN` tinyint(1) NOT NULL,
  `EMOTIONAL_PROBLEM` tinyint(1) NOT NULL,
  `EMOTIONAL_REFERRAL` tinyint(1) NOT NULL,
  `GROWTH_SCREEN` tinyint(1) NOT NULL,
  `GROWTH_PROBLEM` tinyint(1) NOT NULL,
  `GROWTH_REFERRAL` tinyint(1) NOT NULL,
  `ASQ_LAST_UPDATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ASQ_SCREENING_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asq_screening`
--

INSERT INTO `asq_screening` (`ASQ_SCREENING_ID`, `CHILD_ID`, `EPSDT_VISITS`, `COMMUNICATION_SCREEN`, `COMMUNICATION_PROBLEM`, `COMMUNICATION_REFERRAL`, `PERSONAL_SCREEN`, `PERSONAL_PROBLEM`, `PERSONAL_REFERRAL`, `SOLVING_SCREEN`, `SOLVING_PROBLEM`, `SOLVING_REFERRAL`, `EMOTIONAL_SCREEN`, `EMOTIONAL_PROBLEM`, `EMOTIONAL_REFERRAL`, `GROWTH_SCREEN`, `GROWTH_PROBLEM`, `GROWTH_REFERRAL`, `ASQ_LAST_UPDATE`) VALUES
(0, 2, '0', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, '2013-09-21 00:48:15');

-- --------------------------------------------------------

--
-- Table structure for table `child_details`
--

CREATE TABLE IF NOT EXISTS `child_details` (
  `CHILD_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `PARENT_ID` bigint(20) NOT NULL,
  `CHILD_ENROLLMENT_DATE` datetime NOT NULL,
  `CHILD_SSN` bigint(20) NOT NULL,
  `CHILD_LAST_NAME` varchar(30) NOT NULL,
  `CHILD_FIRST_NAME` varchar(30) NOT NULL,
  `CHILD_MIDDLE_NAME` varchar(30) NOT NULL,
  `CHILD_BIRTH_DATE` datetime DEFAULT NULL,
  `CHILD_SEX` varchar(6) NOT NULL,
  `CHILD_RACE` varchar(50) NOT NULL,
  `CHILD_ETHNICITY` varchar(30) NOT NULL,
  PRIMARY KEY (`CHILD_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `child_details`
--

INSERT INTO `child_details` (`CHILD_ID`, `PARENT_ID`, `CHILD_ENROLLMENT_DATE`, `CHILD_SSN`, `CHILD_LAST_NAME`, `CHILD_FIRST_NAME`, `CHILD_MIDDLE_NAME`, `CHILD_BIRTH_DATE`, `CHILD_SEX`, `CHILD_RACE`, `CHILD_ETHNICITY`) VALUES
(1, 1, '0000-00-00 00:00:00', 12345123, 'Doe', 'John', 'Jane', '0000-00-00 00:00:00', 'Male', 'Enrollee Refused', 'Non Hispanic / Latino'),
(2, 2, '0000-00-00 00:00:00', 1234, 'Prince', 'Harry', 'Potter', '0000-00-00 00:00:00', 'Male', 'Asian', 'Hispanic / Latino'),
(3, 2, '0000-00-00 00:00:00', 123123, 'Prince', 'Big', 'Bird', '0000-00-00 00:00:00', 'Male', 'Enrollee Refused', 'Enrollee Refused');

-- --------------------------------------------------------

--
-- Table structure for table `household_survey`
--

CREATE TABLE IF NOT EXISTS `household_survey` (
  `HOUSEHOLD_SURVEY_ID` bigint(20) NOT NULL,
  `PARENT_ID` bigint(20) NOT NULL,
  `HOUSEHOLD_INCOME` varchar(20) NOT NULL,
  `TOTAL_ADULTS` varchar(20) NOT NULL,
  `TOTAL_CHILDREN` varchar(20) NOT NULL,
  `EMPLOYMENT_STATUS` varchar(30) NOT NULL,
  `LOST_JOB` tinyint(1) NOT NULL,
  `TANF` tinyint(1) NOT NULL,
  `FOOD_STAMPS` tinyint(1) NOT NULL,
  `ARRESTS` tinyint(1) NOT NULL,
  `CONVICTED_CRIME` tinyint(1) NOT NULL,
  `DOMESTIC_VIOLENCE` tinyint(1) NOT NULL,
  `SAFE_PLAN` tinyint(1) NOT NULL,
  `EDUCATION_OBTAINED` varchar(55) DEFAULT NULL,
  `CURRENTLY_ENROLLED` tinyint(1) NOT NULL,
  `PLANNING_TO_ENROLL` tinyint(1) NOT NULL,
  `INSURANCE_STATUS` varchar(30) NOT NULL,
  `LAST_CHECKUP` varchar(30) NOT NULL,
  `PARTICIPANT_SMOKE` tinyint(1) NOT NULL,
  `SMOKING_FREQUENCY` varchar(30) NOT NULL,
  `ATTEMPTED_QUIT_SMOKING` tinyint(1) NOT NULL,
  `SAFE_SLEEPING` tinyint(1) NOT NULL DEFAULT '0',
  `SHAKEN_BABY_SYNDROME` tinyint(1) NOT NULL DEFAULT '0',
  `PASENGER_SAFETY` tinyint(1) NOT NULL DEFAULT '0',
  `POISONING` tinyint(1) NOT NULL DEFAULT '0',
  `FIRE_SAFETY` tinyint(1) NOT NULL DEFAULT '0',
  `WATER_SAFETY` tinyint(1) NOT NULL DEFAULT '0',
  `PLAYGROUND_SAFETY` tinyint(1) NOT NULL,
  `HOUSEHOLD_LAST_UPDATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`HOUSEHOLD_SURVEY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `insurance_status`
--

CREATE TABLE IF NOT EXISTS `insurance_status` (
  `INSURANCE_STATUS_ID` bigint(20) NOT NULL,
  `CHILD_ID` bigint(20) NOT NULL,
  `STATUS` varchar(30) NOT NULL,
  `INSURANCE_LAST_UPDATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`INSURANCE_STATUS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurance_status`
--

INSERT INTO `insurance_status` (`INSURANCE_STATUS_ID`, `CHILD_ID`, `STATUS`, `INSURANCE_LAST_UPDATE`) VALUES
(0, 1, 'Medicaid / SCHCHIP', '2013-09-20 21:04:18');

-- --------------------------------------------------------

--
-- Table structure for table `kips_home_screening`
--

CREATE TABLE IF NOT EXISTS `kips_home_screening` (
  `KIPS_HOME_SCREENING_ID` bigint(20) NOT NULL,
  `CHILD_ID` bigint(20) NOT NULL,
  `KIPS_SCORE` varchar(20) NOT NULL,
  `DEMONSTRATES_SUPPORT` tinyint(1) NOT NULL,
  `DEMONSTRATES_KNOWLEDGE` tinyint(1) NOT NULL,
  `POSITIVE_BEHAVIOR` tinyint(1) NOT NULL,
  `KIPS_LAST_UPDATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`KIPS_HOME_SCREENING_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kips_home_screening`
--

INSERT INTO `kips_home_screening` (`KIPS_HOME_SCREENING_ID`, `CHILD_ID`, `KIPS_SCORE`, `DEMONSTRATES_SUPPORT`, `DEMONSTRATES_KNOWLEDGE`, `POSITIVE_BEHAVIOR`, `KIPS_LAST_UPDATE`) VALUES
(0, 3, '123', 0, 0, 1, '2013-09-21 00:48:30');

-- --------------------------------------------------------

--
-- Table structure for table `parent_details`
--

CREATE TABLE IF NOT EXISTS `parent_details` (
  `PARENT_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ENROLLMENT_DATE` datetime DEFAULT NULL,
  `SSN` bigint(20) NOT NULL,
  `LAST_NAME` varchar(30) NOT NULL,
  `FIRST_NAME` varchar(30) NOT NULL,
  `MIDDLE_NAME` varchar(30) NOT NULL,
  `BIRTH_DATE` datetime DEFAULT NULL,
  `SEX` varchar(6) NOT NULL,
  `MARITAL_STATUS` varchar(30) NOT NULL,
  `RACE` varchar(30) NOT NULL,
  `ETHNICITY` varchar(30) NOT NULL,
  `LANGUAGE` varchar(30) NOT NULL,
  `ADDRESS_LINE_1` varchar(40) NOT NULL,
  `ADDRESS_LINE_2` varchar(30) NOT NULL,
  `CITY` varchar(30) NOT NULL,
  `STATE` varchar(2) NOT NULL,
  `ZIP` int(11) NOT NULL,
  `HOME_PHONE` int(11) DEFAULT NULL,
  `MOBILE_PHONE` int(11) DEFAULT NULL,
  `NEEDING_SERVICES` tinyint(1) NOT NULL,
  `REFERRAL_MADE` tinyint(1) NOT NULL,
  `FOLLOW_UP` tinyint(1) NOT NULL,
  PRIMARY KEY (`PARENT_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `parent_details`
--

INSERT INTO `parent_details` (`PARENT_ID`, `ENROLLMENT_DATE`, `SSN`, `LAST_NAME`, `FIRST_NAME`, `MIDDLE_NAME`, `BIRTH_DATE`, `SEX`, `MARITAL_STATUS`, `RACE`, `ETHNICITY`, `LANGUAGE`, `ADDRESS_LINE_1`, `ADDRESS_LINE_2`, `CITY`, `STATE`, `ZIP`, `HOME_PHONE`, `MOBILE_PHONE`, `NEEDING_SERVICES`, `REFERRAL_MADE`, `FOLLOW_UP`) VALUES
(1, '0000-00-00 00:00:00', 123456789, 'Johnson', 'Michael', 'Ronald', '0000-00-00 00:00:00', 'Male', 'Single', 'Black / African American', 'Enrollee Refused', 'English', '1234 Lane', 'Apt 103', 'Kirkland', 'SC', 29841, 2147483647, 12, 0, 0, 0),
(2, '0000-00-00 00:00:00', 5412345, 'Prince', 'Freddy', 'Mike', '0000-00-00 00:00:00', 'Female', 'Unknown', 'Black / African American', 'Non Hispanic / Latino', 'Arabic', '407 Bloedel Reserve Way', '', 'North Augusta', 'SC', 29841, 742323, 3124234, 0, 0, 0),
(3, '0000-00-00 00:00:00', 1234, 'Geisser', 'Fergy', 'B', '0000-00-00 00:00:00', 'Female', 'Unknown', 'Unknown', 'Unknown', 'English', '234', '234', 'Hooper', 'UT', 84606, 8123, 234, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `postpartum_mothers`
--

CREATE TABLE IF NOT EXISTS `postpartum_mothers` (
  `POSTPARTUM_MOTHERS_ID` bigint(20) NOT NULL,
  `PARENT_ID` bigint(20) NOT NULL,
  `REPEATED_PREGNANCY` tinyint(1) NOT NULL DEFAULT '0',
  `PREGNANCY_DATE` datetime DEFAULT NULL,
  `DEPRESSION_SCREENED` tinyint(1) NOT NULL DEFAULT '0',
  `SCREENING_DATE` datetime NOT NULL,
  `BREAST_FEEDING` tinyint(1) NOT NULL DEFAULT '0',
  `WEEKS_BEFORE_BREAST_FEEDING` int(11) NOT NULL,
  `STRESS_LEVEL` varchar(20) NOT NULL,
  `SUPPORT_SYSTEM` varchar(20) NOT NULL,
  `POSTPARTUM_LAST_UPDATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`POSTPARTUM_MOTHERS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postpartum_mothers`
--

INSERT INTO `postpartum_mothers` (`POSTPARTUM_MOTHERS_ID`, `PARENT_ID`, `REPEATED_PREGNANCY`, `PREGNANCY_DATE`, `DEPRESSION_SCREENED`, `SCREENING_DATE`, `BREAST_FEEDING`, `WEEKS_BEFORE_BREAST_FEEDING`, `STRESS_LEVEL`, `SUPPORT_SYSTEM`, `POSTPARTUM_LAST_UPDATE`) VALUES
(0, 1, 0, '0000-00-00 00:00:00', 1, '0000-00-00 00:00:00', 1, 12, 'Unknown', 'No', '2013-09-21 00:49:59');

-- --------------------------------------------------------

--
-- Table structure for table `pregnant_mothers`
--

CREATE TABLE IF NOT EXISTS `pregnant_mothers` (
  `PREGNANT_MOTHERS_ID` bigint(20) NOT NULL,
  `PARENT_ID` bigint(20) NOT NULL,
  `WEEKS_AFTER_DR_VISIT` int(11) NOT NULL,
  `MODE_OF_PAY` varchar(80) NOT NULL,
  `NO_OF_CIGS` varchar(30) NOT NULL,
  `DISCUSSED_NO_SMOKING` tinyint(1) NOT NULL DEFAULT '0',
  `ATTEMPT_STOP_SMOKING` varchar(20) NOT NULL,
  `PREGNANT_LAST_UPDATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PREGNANT_MOTHERS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pregnant_mothers`
--

INSERT INTO `pregnant_mothers` (`PREGNANT_MOTHERS_ID`, `PARENT_ID`, `WEEKS_AFTER_DR_VISIT`, `MODE_OF_PAY`, `NO_OF_CIGS`, `DISCUSSED_NO_SMOKING`, `ATTEMPT_STOP_SMOKING`, `PREGNANT_LAST_UPDATE`) VALUES
(0, 1, 12, 'No health insurance to pay for prenatal care', 'Does not smoke', 0, 'Does not smoke', '2013-09-20 20:25:40');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

